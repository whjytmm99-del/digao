/* 底稿 — 云同步（Supabase）
 *
 * 设计原则：
 *   1. 本机永远是可用的（localStorage），云端是副本。断网照常用，联网自动补传。
 *   2. 鉴权走后端，不信任前端。anon key 是公开的，真正的边界是数据库的行级安全（RLS）。
 *   3. 整份文档同步 + 版本号乐观锁。版本对不上就停下来问人，绝不悄悄覆盖。
 *
 * 依赖：无。直接调 Supabase 的 REST 接口。
 */
(function (global) {
  'use strict';

  var CFG_KEY = 'dibao.cloud';     // { url, key }
  var SES_KEY = 'dibao.session';   // { access_token, refresh_token, expires_at, user_id, email }

  /* ---------- 存储 ---------- */
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { } }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) { } }
  function jGet(k) { try { var r = lsGet(k); return r ? JSON.parse(r) : null; } catch (e) { return null; } }
  function jSet(k, o) { lsSet(k, JSON.stringify(o)); }

  /* ---------- 配置 ---------- */
  function config() {
    var c = jGet(CFG_KEY);
    if (c && c.url && c.key) return c;
    var a = global.APP_CONFIG;
    if (a && a.cloudUrl && a.cloudKey) {
      return { url: String(a.cloudUrl).replace(/\/+$/, ''), key: a.cloudKey };
    }
    return null;
  }
  function configured() {
    var c = config();
    return !!(c && c.url && c.key);
  }
  function configure(url, key) {
    url = String(url || '').trim().replace(/\/+$/, '');
    key = String(key || '').trim();
    if (!/^https?:\/\//i.test(url)) throw new Error('地址要以 https:// 开头');
    if (key.length < 20) throw new Error('anon key 看起来不对（太短了）');
    jSet(CFG_KEY, { url: url, key: key });
  }
  function reset() {
    lsDel(CFG_KEY); lsDel(SES_KEY);
  }

  /* ---------- 会话 ---------- */
  function session() { return jGet(SES_KEY); }
  function signedIn() {
    var s = session();
    return !!(s && s.access_token && s.refresh_token);
  }
  function signOutLocal() { lsDel(SES_KEY); }
  function email() { var s = session(); return s ? s.email : ''; }

  function saveSession(d) {
    var old = session() || {};
    var s = {
      access_token: d.access_token,
      refresh_token: d.refresh_token || old.refresh_token || '',
      expires_at: Date.now() + ((d.expires_in || 3600) * 1000),
      user_id: (d.user && d.user.id) || old.user_id || '',
      email: (d.user && d.user.email) || old.email || ''
    };
    jSet(SES_KEY, s);
    return s;
  }

  /* ---------- 网络 ---------- */
  function base() { var c = config(); return c ? c.url : ''; }
  function apiKey() { var c = config(); return c ? c.key : ''; }

  function request(path, opts) {
    opts = opts || {};
    var s = session();
    var headers = {
      'apikey': apiKey(),
      'Content-Type': 'application/json'
    };
    var extra = opts.headers || {};
    for (var k in extra) if (extra.hasOwnProperty(k)) headers[k] = extra[k];
    if (s && s.access_token && opts.auth !== false) headers['Authorization'] = 'Bearer ' + s.access_token;

    var init = { method: opts.method || 'GET', headers: headers };
    if (opts.body !== undefined) init.body = JSON.stringify(opts.body);

    return fetch(base() + path, init).then(function (res) {
      return res.text().then(function (txt) {
        var data = null;
        if (txt) { try { data = JSON.parse(txt); } catch (e) { data = txt; } }
        if (!res.ok) {
          var msg = (data && (data.msg || data.message || data.error_description || data.error || data.hint)) || ('HTTP ' + res.status);
          var err = new Error(msg);
          err.status = res.status;
          err.data = data;
          throw err;
        }
        return data;
      });
    });
  }

  var refreshing = null;
  function ensureToken() {
    var s = session();
    if (!s) return Promise.reject(new Error('未登录'));
    if (s.expires_at && s.expires_at - 90000 > Date.now()) return Promise.resolve(s);
    if (refreshing) return refreshing;

    refreshing = fetch(base() + '/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      headers: { 'apikey': apiKey(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: s.refresh_token })
    }).then(function (res) {
      return res.json().then(function (d) {
        if (!res.ok || !d.access_token) { signOutLocal(); throw new Error('登录已过期，请重新登录'); }
        return saveSession(d);
      });
    });

    var done = function () { refreshing = null; };
    refreshing.then(done, done);
    return refreshing;
  }

  /* ---------- 登录 / 注册 ---------- */
  function authPost(path, body) {
    return fetch(base() + path, {
      method: 'POST',
      headers: { 'apikey': apiKey(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).then(function (res) {
      return res.json().then(function (d) {
        if (!res.ok) {
          var msg = d.error_description || d.msg || d.message || d.error || '请求失败';
          if (/invalid login credentials/i.test(msg)) msg = '邮箱或密码不对';
          if (/user already registered/i.test(msg)) msg = '这个邮箱已经注册过了，直接登录';
          if (/password.*(short|6)/i.test(msg)) msg = '密码太短，至少 6 位';
          if (/email not confirmed/i.test(msg)) msg = '邮箱还没确认，去收件箱点一下链接';
          throw new Error(msg);
        }
        return d;
      });
    });
  }

  function signIn(email, password) {
    return authPost('/auth/v1/token?grant_type=password', { email: email, password: password })
      .then(function (d) {
        if (!d.access_token) throw new Error('登录失败');
        return saveSession(d);
      });
  }

  function signUp(email, password) {
    return authPost('/auth/v1/signup', { email: email, password: password })
      .then(function (d) {
        if (d.access_token) return { session: saveSession(d), needConfirm: false };
        return { session: null, needConfirm: true };
      });
  }

  /* ---------- 数据 ---------- */
  function pull() {
    return ensureToken()
      .then(function () { return request('/rest/v1/state?select=doc,rev,updated_at&limit=1'); })
      .then(function (rows) {
        if (!rows || !rows.length) return null;
        var r = rows[0];
        return { doc: r.doc, rev: Number(r.rev), updated_at: r.updated_at };
      });
  }

  function conflictErr() {
    var e = new Error('conflict');
    e.code = 'conflict';
    return e;
  }

  function push(docString, baseRev) {
    return ensureToken().then(function () {
      var s = session();
      var uid = s.user_id;
      var doc = JSON.parse(docString);
      var nextRev = (Number(baseRev) || 0) + 1;
      var body = { doc: doc, rev: nextRev, updated_at: new Date().toISOString() };

      if (!baseRev) {
        var row = { user_id: uid, doc: doc, rev: 1, updated_at: new Date().toISOString() };
        return request('/rest/v1/state', {
          method: 'POST',
          headers: { 'Prefer': 'return=representation' },
          body: row
        }).then(function (rows) {
          return { rev: Number(rows && rows[0] ? rows[0].rev : 1) };
        }).catch(function (e) {
          if (e.status === 409) throw conflictErr();
          throw e;
        });
      }

      return request('/rest/v1/state?user_id=eq.' + uid + '&rev=eq.' + baseRev, {
        method: 'PATCH',
        headers: { 'Prefer': 'return=representation' },
        body: body
      }).then(function (rows) {
        if (!rows || !rows.length) throw conflictErr();
        return { rev: Number(rows[0].rev) };
      });
    });
  }

  /* ---------- 快照（历史版本） ---------- */
  function snapshot(docString, rev) {
    return ensureToken().then(function () {
      return request('/rest/v1/snapshots', {
        method: 'POST',
        headers: { 'Prefer': 'return=minimal' },
        body: { user_id: session().user_id, doc: JSON.parse(docString), rev: Number(rev) || 0 }
      });
    });
  }
  function listSnapshots() {
    return ensureToken()
      .then(function () { return request('/rest/v1/snapshots?select=id,rev,created_at&order=created_at.desc&limit=20'); })
      .then(function (rows) { return rows || []; });
  }
  function getSnapshot(id) {
    return ensureToken()
      .then(function () { return request('/rest/v1/snapshots?id=eq.' + encodeURIComponent(id) + '&select=doc,rev,created_at'); })
      .then(function (rows) { return rows && rows.length ? rows[0] : null; });
  }

  global.Cloud = {
    config: config,
    configured: configured,
    configure: configure,
    reset: reset,
    signedIn: signedIn,
    email: email,
    signIn: signIn,
    signUp: signUp,
    signOut: function () { signOutLocal(); },
    pull: pull,
    push: push,
    snapshot: snapshot,
    listSnapshots: listSnapshots,
    getSnapshot: getSnapshot
  };
})(window);
