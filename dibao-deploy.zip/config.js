/* 云端配置：打包时写进这里，用户侧完全不需要填地址和 key。
 * 留空 = 本地模式（数据只在这台设备）。
 */
window.APP_CONFIG = {
  cloudUrl: 'https://tjlcbawtsxzzwndbrzyr.supabase.co',
  cloudKey: 'sb_publishable_RHpvtRGZzifrPuuF_QZmjg_5xN9pQSp'
};
