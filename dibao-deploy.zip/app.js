/* 底稿 — 个人记录 / 复盘 / 沉淀
 * 纯前端、单机、数据存 localStorage，导出的 JSON 就是全部数据。
 * 无框架、无依赖，直接改这一份文件即可扩展。
 */
(function () {
  'use strict';

  /* ================= 常量 ================= */
  var KEY = 'dibao.v1';
  var BAK = 'dibao.v1.bak';
  var WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
  var PLACEHOLDER = {
    flow: '今天做了什么…',
    idea: '突然想到…',
    todo: '要做什么…'
  };

  /* ================= 工具 ================= */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function pad2(n) { return n < 10 ? '0' + n : '' + n; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function nl2br(s) { return esc(s).replace(/\n/g, '<br>'); }
  function clamp(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n) + '…' : s; }

  // 去掉 @某人 和 #标签，只留正文（卡片标题用）
  function stripRefs(s) {
    return String(s || '')
      .replace(/[@#][^\s@#，。,.!?！？、；;：:]+/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /* 搜索：多词 AND 匹配 + 命中高亮 */
  function splitTerms(q) {
    return String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
  }
  function hit(text, ts) {
    if (!ts.length) return false;
    var t = String(text || '').toLowerCase();
    for (var i = 0; i < ts.length; i++) if (t.indexOf(ts[i]) < 0) return false;
    return true;
  }
  function hitList(arr, ts) { return hit((arr || []).join(' '), ts); }

  function hl(text, ts) {
    var s = String(text == null ? '' : text);
    if (!ts.length) return esc(s);
    var low = s.toLowerCase();
    var ranges = [];
    ts.forEach(function (t) {
      var i = low.indexOf(t), guard = 0;
      while (i >= 0 && guard++ < 50) {
        ranges.push([i, i + t.length]);
        i = low.indexOf(t, i + Math.max(1, t.length));
      }
    });
    if (!ranges.length) return esc(s);
    ranges.sort(function (a, b) { return a[0] - b[0]; });
    var merged = [];
    ranges.forEach(function (r) {
      var last = merged[merged.length - 1];
      if (last && r[0] <= last[1]) last[1] = Math.max(last[1], r[1]);
      else merged.push([r[0], r[1]]);
    });
    var out = '', pos = 0;
    merged.forEach(function (r) {
      out += esc(s.slice(pos, r[0])) + '<mark class="hl">' + esc(s.slice(r[0], r[1])) + '</mark>';
      pos = r[1];
    });
    return out + esc(s.slice(pos));
  }

  // 长文本只保留命中附近的一段
  function snip(text, ts, max) {
    var s = String(text || ''), low = s.toLowerCase();
    max = max || 90;
    if (s.length <= max) return s;
    var at = -1;
    for (var i = 0; i < ts.length && at < 0; i++) at = low.indexOf(ts[i]);
    if (at < 0) return s.slice(0, max) + '…';
    var start = Math.max(0, at - Math.floor(max / 3));
    var end = Math.min(s.length, start + max);
    return (start > 0 ? '…' : '') + s.slice(start, end) + (end < s.length ? '…' : '');
  }

  function dayKey(ts) {
    var d = new Date(ts);
    return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  }
  function hm(ts) {
    var d = new Date(ts);
    return pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }
  function startOfDay(ts) { var d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); }
  function weekStartOf(ts) {
    var d = new Date(startOfDay(ts));
    var wd = (d.getDay() + 6) % 7; // 周一为一周开始
    d.setDate(d.getDate() - wd);
    return d.getTime();
  }
  function dayLabel(ts) {
    var k = dayKey(ts), now = dayKey(Date.now());
    if (k === now) return '今天';
    if (k === dayKey(Date.now() - 86400000)) return '昨天';
    var d = new Date(ts);
    return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' + WEEKDAYS[d.getDay()];
  }
  function md(ts) { var d = new Date(ts); return (d.getMonth() + 1) + '月' + d.getDate() + '日'; }
  function relTime(ts) {
    if (!ts) return '';
    var diff = Date.now() - ts;
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' 分钟前';
    if (diff < 86400000) return Math.floor(diff / 3600000) + ' 小时前';
    var days = Math.floor(diff / 86400000);
    if (days < 30) return days + ' 天前';
    return md(ts);
  }
  function relDays(ts) {
    if (!ts) return '';
    var days = Math.floor((Date.now() - ts) / 86400000);
    if (days <= 0) return '今天联系过';
    if (days === 1) return '昨天联系过';
    return days + ' 天前联系过';
  }
  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  }

  var toastTimer;
  function toast(msg) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 1900);
  }

  /* ================= 数据层 ================= */
  function emptyDB() {
    return { v: 1, events: [], todos: [], people: [], cards: [], reviews: [], reports: [], meta: { created: Date.now(), lastBackup: 0 } };
  }
  function normalize(d) {
    var base = emptyDB();
    if (!d || typeof d !== 'object') return base;
    return {
      v: 1,
      events: Array.isArray(d.events) ? d.events : [],
      todos: Array.isArray(d.todos) ? d.todos : [],
      people: Array.isArray(d.people) ? d.people : [],
      cards: Array.isArray(d.cards) ? d.cards : [],
      reviews: Array.isArray(d.reviews) ? d.reviews : [],
      reports: Array.isArray(d.reports) ? d.reports : [],
      meta: Object.assign(base.meta, d.meta || {})
    };
  }

  var db = emptyDB();

  function loadDB() {
    var raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { }
    if (raw) {
      try {
        db = normalize(JSON.parse(raw));
      } catch (e) {
        try {
          var b = localStorage.getItem(BAK);
          db = b ? normalize(JSON.parse(b)) : emptyDB();
        } catch (e2) { db = emptyDB(); }
      }
    } else {
      db = emptyDB();
    }
  }

  function writeLocal() {
    try {
      localStorage.setItem(KEY, JSON.stringify(db));
    } catch (e) {
      toast('保存失败：存储空间可能已满');
    }
  }

  function saveDB() {
    db.meta.dirty = true;
    writeLocal();
    cloud.seq++;
    schedulePush();
  }

  // 每天第一次打开时，留一份本地快照，防止手滑/数据损坏
  function dailySnapshot() {
    var today = dayKey(Date.now());
    if (db.meta.bakDay === today) return;
    if (!db.events.length && !db.cards.length) return;
    try { localStorage.setItem(BAK, JSON.stringify(db)); } catch (e) { }
    db.meta.bakDay = today;
    writeLocal();
  }

  /* ================= 云同步 ================= */
  var cloud = {
    state: 'off',     // off | login | idle | syncing | ok | error | conflict
    busy: false,
    pending: false,
    seq: 0,
    timer: null
  };

  function hasCloud() { return !!(window.Cloud && Cloud.configured()); }
  function hasLocalData() {
    return !!(db.events.length || db.cards.length || db.people.length || db.todos.length);
  }
  function countAll(doc) {
    var d = normalize(doc);
    return d.events.length + d.cards.length + d.people.length + d.todos.length + d.reviews.length;
  }

  function syncStatusHTML() {
    if (!hasCloud()) return '<span class="sync-dot"></span>本机存储（没连云端）';
    if (!Cloud.signedIn()) return '<span class="sync-dot warn"></span>未登录，数据只在这台设备';
    var map = {
      ok: ['ok', '已同步到云端'],
      syncing: ['warn', '正在同步…'],
      error: ['err', '同步失败，联网后会重试'],
      conflict: ['err', '有冲突，要你选一次'],
      login: ['warn', '登录已过期'],
      idle: ['', '等待同步']
    };
    var m = map[cloud.state] || map.idle;
    return '<span class="sync-dot ' + m[0] + '"></span>' + m[1];
  }

  function updateSyncUI() {
    var el = $('#syncStatus');
    if (el) el.innerHTML = syncStatusHTML();
    updateAuthGate();
  }

  function schedulePush() {
    if (!hasCloud() || !Cloud.signedIn()) return;
    clearTimeout(cloud.timer);
    cloud.timer = setTimeout(doPush, 1200);
  }

  function doPush() {
    if (!hasCloud() || !Cloud.signedIn()) return;
    if (cloud.busy) { cloud.pending = true; return; }

    cloud.busy = true;
    cloud.state = 'syncing';
    updateSyncUI();

    var rev = Number(db.meta.rev) || 0;
    var body = JSON.stringify(db);
    var seq = cloud.seq;

    Cloud.push(body, rev).then(function (r) {
      db.meta.rev = r.rev;
      if (cloud.seq === seq) db.meta.dirty = false;
      writeLocal();
      cloud.state = 'ok';
      return maybeCloudSnapshot();
    }).catch(function (err) {
      if (err && (err.code === 'conflict' || err.status === 409)) {
        cloud.state = 'conflict';
        resolveConflict();
      } else {
        cloud.state = 'error';
        toast('云同步失败：' + (err && err.message ? err.message : '网络问题'));
      }
    }).then(function () {
      cloud.busy = false;
      updateSyncUI();
      if (cloud.pending) { cloud.pending = false; doPush(); }
      else if (db.meta.dirty && cloud.state === 'ok') schedulePush();
    });
  }

  // 每天存一份云端快照，作为「历史版本」
  function maybeCloudSnapshot() {
    var today = dayKey(Date.now());
    if (db.meta.snapDay === today) return Promise.resolve();
    if (!hasLocalData()) return Promise.resolve();
    return Cloud.snapshot(JSON.stringify(db), db.meta.rev).then(function () {
      db.meta.snapDay = today;
      writeLocal();
    }).catch(function () { });
  }

  function adoptRemote(remote) {
    var prev = JSON.stringify(db);
    if (hasLocalData()) Cloud.snapshot(prev, db.meta.rev || 0).catch(function () { });
    db = normalize(remote.doc);
    db.meta.rev = remote.rev;
    db.meta.dirty = false;
    writeLocal();
    cloud.state = 'ok';
    render();
    toast('已拉取云端数据');
  }

  function resolveConflict(remote) {
    var open = function (r) {
      if (!r) { doPush(); return; }
      openConflictSheet(r);
    };
    if (remote) { open(remote); return; }
    Cloud.pull().then(open).catch(function (e) {
      toast('拉取云端失败：' + (e.message || ''));
    });
  }

  function openConflictSheet(remote) {
    var rc = countAll(remote.doc);
    var lc = countAll(db);
    openSheet(
      '<div class="sheet__title">两边都有改动</div>' +
      '<div class="muted" style="margin-bottom:14px;line-height:1.8">云端：' + rc + ' 条<br>这台设备：' + lc + ' 条<br><br>' +
      '我不替你选。选错的那一份会先存成快照，之后能在「历史版本」里找回。</div>' +
      '<div class="menu-list">' +
      '<button type="button" id="cfRemote">用云端的<small>覆盖这台设备</small></button>' +
      '<button type="button" id="cfLocal">用这台设备的<small>覆盖云端</small></button>' +
      '</div>',
      function (sh) {
        $('#cfRemote', sh).onclick = function () {
          Cloud.snapshot(JSON.stringify(db), db.meta.rev || 0).catch(function () { });
          closeSheet();
          adoptRemote(remote);
        };
        $('#cfLocal', sh).onclick = function () {
          Cloud.snapshot(JSON.stringify(remote.doc), remote.rev).catch(function () { });
          closeSheet();
          db.meta.rev = remote.rev;
          db.meta.dirty = true;
          writeLocal();
          doPush();
        };
      });
  }

  function cloudBoot() {
    if (!hasCloud()) { cloud.state = 'off'; updateSyncUI(); return; }
    if (!Cloud.signedIn()) { cloud.state = 'login'; updateSyncUI(); return; }

    cloud.state = 'syncing';
    updateSyncUI();

    Cloud.pull().then(function (remote) {
      if (!remote) {
        cloud.state = 'ok';
        if (hasLocalData()) doPush();
        return;
      }
      var localRev = Number(db.meta.rev) || 0;
      if (remote.rev === localRev) {
        if (db.meta.dirty) doPush();
        else { cloud.state = 'ok'; updateSyncUI(); }
        return;
      }
      if (remote.rev > localRev) {
        // 云端是空的，而本机有数据、且从没同步过（多半是在别的设备上刚注册）→ 以本机为准，别拿空文档覆盖
        if (!db.meta.dirty && localRev === 0 && hasLocalData() && countAll(remote.doc) === 0) {
          db.meta.rev = remote.rev;
          db.meta.dirty = true;
          writeLocal();
          doPush();
          return;
        }
        if (!db.meta.dirty) adoptRemote(remote);
        else { cloud.state = 'conflict'; resolveConflict(remote); }
        return;
      }
      doPush();
    }).catch(function (err) {
      if (err && /重新登录/.test(err.message || '')) {
        cloud.state = 'login';
      } else {
        cloud.state = 'error';
      }
      updateSyncUI();
    });
  }

  /* ---------- 登录界面 ---------- */
  var authMode = 'in';
  var offlineUse = false;

  function updateAuthGate() {
    var gate = $('#authGate');
    if (!gate) return;
    var need = hasCloud() && !Cloud.signedIn() && !offlineUse;
    gate.classList.toggle('hide', !need);
    var off = $('#authOffline');
    if (off) off.style.display = hasLocalData() ? '' : 'none';
    if (!need) return;
    $('#authGo').textContent = authMode === 'up' ? '注册' : '登录';
    $('#authMode').textContent = authMode === 'up' ? '已经有账号？去登录' : '还没有账号？注册一个';
    $('#authLede').textContent = authMode === 'up'
      ? '建一个只有你自己用的账号。数据写进你自己的云数据库，别的账号读不到。'
      : '登录后，记录会存到云端。换手机、清缓存都不会丢。';
  }

  function wireAuth() {
    var go = $('#authGo');
    if (!go) return;
    go.onclick = authSubmit;
    $('#authPass').addEventListener('keydown', function (e) { if (e.key === 'Enter') authSubmit(); });
    $('#authEmail').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#authPass').focus(); });
    $('#authMode').onclick = function () {
      authMode = authMode === 'in' ? 'up' : 'in';
      $('#authErr').textContent = '';
      updateAuthGate();
    };
    var off = $('#authOffline');
    if (off) {
      off.onclick = function () {
        offlineUse = true;
        updateAuthGate();
        render();
      };
    }
  }

  function authSubmit() {
    var email = $('#authEmail').value.trim();
    var pass = $('#authPass').value;
    var err = $('#authErr');
    var btn = $('#authGo');
    err.style.color = '';
    err.textContent = '';

    if (!email) { err.textContent = '填一下邮箱'; return; }
    if (pass.length < 6) { err.textContent = '密码至少 6 位'; return; }

    btn.disabled = true;
    btn.textContent = authMode === 'up' ? '注册中…' : '登录中…';

    var p = authMode === 'up' ? Cloud.signUp(email, pass) : Cloud.signIn(email, pass);

    p.then(function (r) {
      if (r && r.needConfirm) {
        err.style.color = 'var(--accent)';
        err.textContent = '注册成功。去邮箱点确认链接，然后回来登录。';
        authMode = 'in';
        updateAuthGate();
        return;
      }
      $('#authPass').value = '';
      offlineUse = false;
      updateAuthGate();
      toast(authMode === 'up' ? '账号已建好' : '已登录');
      cloudBoot();
    }).catch(function (e) {
      err.textContent = e.message || '出错了，再试一次';
    }).then(function () {
      btn.disabled = false;
      updateAuthGate();
    });
  }

  /* ---------- 云端设置（打包时写进 config.js，App 里不再让用户填） ---------- */

  function openHistory() {
    openSheet(
      '<div class="sheet__title">历史版本</div>' +
      '<div class="muted" id="histBody">读取中…</div>',
      function (sh) {
        Cloud.listSnapshots().then(function (rows) {
          var body = $('#histBody', sh);
          if (!body) return;
          if (!rows.length) {
            body.innerHTML = '还没有历史版本。每天第一次同步时会自动存一份。';
            return;
          }
          body.innerHTML = rows.map(function (r) {
            var d = new Date(r.created_at);
            return '<div class="row spread" style="padding:10px 0;border-bottom:1px solid var(--line)">' +
              '<div><div style="font-size:14.5px">' + (d.getMonth() + 1) + '月' + d.getDate() + '日 ' +
              pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + '</div>' +
              '<div class="faint">第 ' + r.rev + ' 版</div></div>' +
              '<button class="btn btn--sm" type="button" data-restore="' + r.id + '">恢复</button></div>';
          }).join('');
          $$('[data-restore]', sh).forEach(function (b) {
            b.onclick = function () { restoreSnapshot(b.getAttribute('data-restore')); };
          });
        }).catch(function (e) {
          var body = $('#histBody', sh);
          if (body) body.textContent = '读取失败：' + (e.message || '');
        });
      });
  }

  function restoreSnapshot(id) {
    if (!confirm('恢复到这一版？当前版本会先存一份快照。')) return;
    Cloud.getSnapshot(id).then(function (snap) {
      if (!snap) { toast('找不到这个版本'); return; }
      var curRev = Number(db.meta.rev) || 0;
      Cloud.snapshot(JSON.stringify(db), curRev).catch(function () { });
      db = normalize(snap.doc);
      db.meta.rev = curRev;
      db.meta.dirty = true;
      writeLocal();
      closeSheet();
      render();
      doPush();
      toast('已恢复');
    }).catch(function (e) { toast('恢复失败：' + (e.message || '')); });
  }

  function doSignOut() {
    if (!confirm('退出登录？这台设备的记录会保留，但不再往云端同步。')) return;
    Cloud.signOut();
    cloud.state = 'login';
    offlineUse = false;
    updateSyncUI();
    render();
  }

  /* ================= 人 ================= */
  function findPersonByName(name) {
    var n = String(name || '').trim().toLowerCase();
    if (!n) return null;
    for (var i = 0; i < db.people.length; i++) {
      if (String(db.people[i].name || '').trim().toLowerCase() === n) return db.people[i];
    }
    return null;
  }
  function getPerson(id) {
    for (var i = 0; i < db.people.length; i++) if (db.people[i].id === id) return db.people[i];
    return null;
  }
  function ensurePerson(name) {
    var p = findPersonByName(name);
    if (p) return { person: p, created: false };
    p = { id: uid(), name: String(name).trim(), facts: '', hook: '', created: Date.now(), lastTouch: 0 };
    db.people.push(p);
    return { person: p, created: true };
  }
  function touchPeople(ids, ts) {
    (ids || []).forEach(function (id) {
      var p = getPerson(id);
      if (p && (!p.lastTouch || p.lastTouch < ts)) p.lastTouch = ts;
    });
  }
  function personName(id) { var p = getPerson(id); return p ? p.name : ''; }

  /* 解析 @某人 与 #标签 */
  /* 规则解析：@人 / #标签 / 承诺句
   * 不调大模型，纯规则。宁可不认，也不要认错——认错了要手动删，比没认出来更烦。
   */
  var TIME_WORDS = /(今天|今晚|明早|明天|后天|大后天|这周|本周|下周|周末|月底|下个月|周[一二三四五六日天]|星期[一二三四五六日天]|\d{1,2}月\d{1,2}[日号]|\d{1,2}号)/;
  var COMMIT_VERB = /(答应|承诺|说好|约好|保证|回头)/;
  var ACTION_VERB = /(给|发|交|送|回|找|做|带|买|订|写|打|约|问|还|推|整理|确认)/;
  var THEY_OWE = /(答应我|说好给我|回头给我|会给我|他答应|她答应|他承诺|她承诺)/;

  function detectCommitment(text, people) {
    if (!people.length) return null;
    var t = String(text || '');
    var time = TIME_WORDS.exec(t);
    var commit = COMMIT_VERB.test(t);
    var action = ACTION_VERB.test(t);
    if (!commit && !(time && action)) return null;

    var task = stripRefs(t)
      .replace(/(我答应|我承诺|我保证|答应他|答应她|答应你|回头|说好|承诺|会|要)/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    if (task.length < 2) task = stripRefs(t);

    return {
      personId: people[0],
      dir: THEY_OWE.test(t) ? 'them' : 'me',
      due: time ? time[0] : '',
      text: clamp(task, 60)
    };
  }

  function parseEntry(text) {
    var tags = [], people = [], created = [], m;
    var reTag = /#([^\s#@，。,.!?！？、；;：:]+)/g;
    while ((m = reTag.exec(text))) if (tags.indexOf(m[1]) < 0) tags.push(m[1]);
    var reAt = /@([^\s@#，。,.!?！？、；;：:]+)/g;
    while ((m = reAt.exec(text))) {
      var r = ensurePerson(m[1]);
      if (people.indexOf(r.person.id) < 0) people.push(r.person.id);
      if (r.created) created.push(r.person.name);
    }
    return { tags: tags, people: people, created: created, commitment: detectCommitment(text, people) };
  }

  /* 中文高频词：滑窗取二字词，去掉虚词，出现 ≥2 次才算 */
  var STOP_CHARS = '的了是我你他她在有就不也都和又这那个一下上来到说很没还要会能去对给被把从';
  function topWords(text, limit) {
    var s = String(text || '').replace(/[^\u4e00-\u9fa5]/g, ' ');
    var parts = s.split(/\s+/);
    var count = {};
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      for (var j = 0; j + 2 <= p.length; j++) {
        var w = p.substr(j, 2);
        if (STOP_CHARS.indexOf(w.charAt(0)) >= 0 || STOP_CHARS.indexOf(w.charAt(1)) >= 0) continue;
        if (w.charAt(0) === w.charAt(1)) continue;
        count[w] = (count[w] || 0) + 1;
      }
    }
    var arr = [];
    for (var k in count) if (count[k] >= 2) arr.push({ w: k, n: count[k] });
    arr.sort(function (a, b) { return b.n - a.n || a.w.localeCompare(b.w); });
    return arr.slice(0, limit || 6);
  }

  /* ================= 状态 ================= */
  var viewDate = startOfDay(Date.now());
  var composerType = 'flow';
  var cardsMode = 'cards';       // cards | ideas
  var cardsQuery = '';
  var peopleQuery = '';
  var searchQuery = '';
  var cardSort = 'recent';
  var weekOffset = 0;
  var draft = '';
  var nextOpen = false;
  var nextDraft = '';
  var showDone = false;
  var lastRouteKey = '__init__';

  /* ================= 路由 ================= */
  function parseRoute() {
    var h = (location.hash || '').replace(/^#\/?/, '');
    var parts = h.split('/').filter(Boolean);
    return { name: parts[0] || 'today', arg: parts[1] || '' };
  }
  function go(hash) {
    if (location.hash === hash) render();
    else location.hash = hash;
  }
  function setTab(name) {
    var map = { today: 'today', people: 'people', person: 'people', cards: 'cards', review: 'review', search: '' };
    var tab = map[name] || '';
    $$('#tabbar button').forEach(function (b) {
      b.setAttribute('aria-current', b.getAttribute('data-tab') === tab ? 'true' : 'false');
    });
  }

  /* ================= 通用片段 ================= */
  function backupAgeDays() {
    var last = db.meta.lastBackup || 0;
    if (!last) return 999;
    return Math.floor((Date.now() - last) / 86400000);
  }

  function backupBanner() {
    var days = backupAgeDays();
    var total = db.events.length + db.cards.length;
    if (days === 999) { if (total < 15) return ''; }
    else if (days < 7) return '';
    var text = days === 999
      ? '数据只存在这台设备上，还没备份过。'
      : '已经 ' + days + ' 天没备份了，数据只存在这台设备上。';
    return '<div class="banner"><div>' + text + '浏览器清理缓存会把它一起删掉。</div>' +
      '<button type="button" data-act="backup">导出</button></div>';
  }

  function tagHTML(t) { return '<span class="tag">#' + esc(t) + '</span>'; }

  function entryHTML(e) {
    var meta = '';
    (e.people || []).forEach(function (pid) {
      var n = personName(pid);
      if (n) meta += '<span class="tag tag--person">@' + esc(n) + '</span>';
    });
    (e.tags || []).forEach(function (t) { meta += tagHTML(t); });
    if (e.type === 'idea') meta = '<span class="tag tag--idea">想法</span>' + meta;
    return '<div class="entry" data-type="' + (e.type || 'flow') + '">' +
      '<div class="entry__time">' + hm(e.ts) + '</div>' +
      '<div class="entry__body">' +
      '<div class="entry__text" data-act="entry" data-id="' + e.id + '">' + esc(e.text) + '</div>' +
      (meta ? '<div class="entry__meta">' + meta + '</div>' : '') +
      '</div></div>';
  }

  function todoHTML(t) {
    var who = t.personId ? personName(t.personId) : '';
    var whoTxt = '';
    if (who) {
      whoTxt = (t.dir === 'them' ? 'TA 答应我 · ' + who : '我答应 ' + who) + (t.due ? ' · ' + t.due : '');
    } else if (t.due) {
      whoTxt = t.due;
    }
    return '<div class="todo" data-done="' + (t.done ? '1' : '0') + '">' +
      '<button class="todo__check" type="button" data-act="toggle-todo" data-id="' + t.id + '" aria-label="完成">✓</button>' +
      '<div class="todo__text">' + esc(t.text) + (whoTxt ? '<span class="who">' + esc(whoTxt) + '</span>' : '') + '</div>' +
      '</div>';
  }

  function cardHTML(c) {
    var tags = (c.tags || []).map(tagHTML).join('');
    var usedTxt = (c.uses || 0) > 0 ? '用过 ' + c.uses + ' 次' : '还没用过';
    var lastTxt = c.lastUsed ? ' · ' + relTime(c.lastUsed) : '';
    return '<article class="card-item" data-id="' + c.id + '">' +
      '<h3 class="card-item__scene" data-act="edit-card" data-id="' + c.id + '">' + esc(c.scene) + '</h3>' +
      '<div class="card-item__next"><b>下次：</b>' + nl2br(c.next) + '</div>' +
      ((c.did || c.result) ?
        '<details><summary>当时的做法与结果</summary><div class="card-item__detail">' +
        (c.did ? '<b>当时的做法</b>' + nl2br(c.did) : '') +
        (c.result ? '<b style="margin-top:10px">结果</b>' + nl2br(c.result) : '') +
        '</div></details>' : '') +
      '<div class="card-item__foot">' + tags + '<span class="grow"></span>' +
      '<span class="faint">' + usedTxt + lastTxt + '</span>' +
      '<button class="btn btn--sm" type="button" data-act="use-card" data-id="' + c.id + '">这次用上了</button>' +
      '</div></article>';
  }

  function emptyHTML(title, sub) {
    return '<div class="empty"><b>' + esc(title) + '</b>' + esc(sub) + '</div>';
  }

  /* ================= 视图：今天 ================= */
  function viewToday() {
    var todayK = dayKey(Date.now());
    var selK = dayKey(viewDate);
    var isToday = selK === todayK;

    var list = db.events.filter(function (e) { return dayKey(e.ts) === selK; })
      .sort(function (a, b) { return b.ts - a.ts; });

    var openTodos = db.todos.filter(function (t) { return !t.done; })
      .sort(function (a, b) { return a.created - b.created; });
    var doneTodos = db.todos.filter(function (t) {
      return t.done && t.doneAt && dayKey(t.doneAt) === todayK;
    }).sort(function (a, b) { return b.doneAt - a.doneAt; });

    var weekK = weekStartOf(Date.now());
    var weekCount = db.events.filter(function (e) { return e.ts >= weekK; }).length;
    var todayCount = db.events.filter(function (e) { return dayKey(e.ts) === todayK; }).length;

    /* 快记区 */
    var html = backupBanner();
    html += '<div class="composer">' +
      '<div class="seg" role="group" aria-label="记录类型">' +
      '<button type="button" data-act="composer-type" data-type="flow" aria-pressed="' + (composerType === 'flow') + '">流水</button>' +
      '<button type="button" data-act="composer-type" data-type="idea" aria-pressed="' + (composerType === 'idea') + '">想法</button>' +
      '<button type="button" data-act="composer-type" data-type="todo" aria-pressed="' + (composerType === 'todo') + '">待办</button>' +
      '</div>' +
      '<div class="composer__row">' +
      '<textarea id="composerText" rows="1" placeholder="' + esc(PLACEHOLDER[composerType]) + '" autocomplete="off">' + esc(draft) + '</textarea>' +
      '<button class="send" id="sendBtn" type="button" data-act="send" aria-label="发送" disabled>↑</button>' +
      '</div>' +
      (composerType === 'flow'
        ? (nextOpen || nextDraft
          ? '<div class="composer__next"><span>下次</span><input id="nextText" placeholder="再遇到，我会…" value="' + esc(nextDraft) + '" autocomplete="off"></div>'
          : '<button class="composer__addnext" type="button" data-act="toggle-next">＋ 下次怎么做（写一句，就成一张卡）</button>')
        : '') +
      '<div class="composer__hint"><span>Enter 发送 · @人 #标签</span>' +
      '<span>今天 ' + todayCount + ' 条 · 本周 ' + weekCount + ' 条</span></div>' +
      '</div>';

    /* 日期导航 */
    html += '<div class="datenav">' +
      '<div class="datenav__label">' + dayLabel(viewDate) +
      '<small>' + md(viewDate) + ' · ' + list.length + ' 条</small></div>' +
      '<div class="datenav__btns">' +
      '<button type="button" data-act="day-prev" aria-label="前一天">‹</button>' +
      (isToday ? '' : '<button type="button" data-act="day-today" aria-label="回到今天">今天</button>') +
      '<button type="button" data-act="day-next" aria-label="后一天"' + (isToday ? ' disabled style="opacity:.35"' : '') + '>›</button>' +
      '</div></div>';

    /* 流水 */
    if (list.length) {
      html += '<div class="entries">' + list.map(entryHTML).join('') + '</div>';
    } else {
      html += '<div class="empty">' + (isToday
        ? '<b>今天还没有记录</b>写一句话就行，不用完整，不用文采。'
        : '<b>这天是空的</b>没有记录也是一种记录。') + '</div>';
    }

    /* 待办 */
    if (openTodos.length || doneTodos.length) {
      html += '<div class="section-title">待办 <span class="count">' + openTodos.length + '</span></div>' +
        '<div class="panel">' + openTodos.map(todoHTML).join('');
      if (doneTodos.length) {
        html += '<div style="margin-top:6px">' +
          '<button class="mini-link" type="button" data-act="toggle-done">' +
          (showDone ? '收起已完成' : '今天已完成 ' + doneTodos.length + ' 件 · 展开') + '</button></div>';
        if (showDone) html += doneTodos.map(todoHTML).join('');
      }
      html += '</div>';
    }

    return html;
  }

  /* ================= 视图：人 ================= */
  function peopleFiltered() {
    var q = peopleQuery.trim().toLowerCase();
    var arr = db.people.slice();
    if (q) {
      arr = arr.filter(function (p) {
        return (p.name || '').toLowerCase().indexOf(q) >= 0 ||
          (p.facts || '').toLowerCase().indexOf(q) >= 0 ||
          (p.hook || '').toLowerCase().indexOf(q) >= 0;
      });
    }
    arr.sort(function (a, b) {
      var la = a.lastTouch || 0, lb = b.lastTouch || 0;
      if (la !== lb) return la - lb;
      return (a.name || '').localeCompare(b.name || '', 'zh');
    });
    return arr;
  }

  function peopleListHTML() {
    var arr = peopleFiltered();
    if (!db.people.length) {
      return emptyHTML('还没有人', '记流水时写 @名字，就会自动建一条档案。');
    }
    if (!arr.length) return emptyHTML('没找到', '换个关键词试试。');
    return arr.map(function (p) {
      var open = db.todos.filter(function (t) { return !t.done && t.personId === p.id; }).length;
      var meta = p.lastTouch ? relDays(p.lastTouch) : '还没有互动记录';
      var stale = p.lastTouch && (Date.now() - p.lastTouch) > 30 * 86400000;
      return '<div class="person-row" data-act="open-person" data-id="' + p.id + '">' +
        '<div class="avatar">' + esc((p.name || '?').slice(0, 1)) + '</div>' +
        '<div class="person-row__main">' +
        '<div class="person-row__name">' + esc(p.name) + '</div>' +
        '<div class="person-row__meta' + (stale ? ' warn' : '') + '">' + esc(meta) + '</div>' +
        '</div>' +
        (open ? '<span class="badge">' + open + ' 件</span>' : '') +
        '</div>';
    }).join('');
  }

  function commitmentsHTML() {
    var open = db.todos.filter(function (t) { return !t.done && t.personId; });
    if (!open.length) return '';
    open.sort(function (a, b) {
      if (!!a.due !== !!b.due) return a.due ? -1 : 1;
      return a.created - b.created;
    });
    var rows = open.map(function (t) {
      var name = esc(personName(t.personId));
      var label = (t.dir === 'them' ? name + ' 欠我' : '我欠 ' + name) + (t.due ? ' · ' + esc(t.due) : '');
      return '<div class="todo" data-done="0">' +
        '<button class="todo__check" type="button" data-act="toggle-todo" data-id="' + t.id + '" aria-label="完成">✓</button>' +
        '<div class="todo__text">' + esc(t.text) + '<span class="who">' + label + '</span></div></div>';
    }).join('');
    return '<div class="section-title">未了的承诺 <span class="count">' + open.length + '</span></div>' +
      '<div class="panel">' + rows + '</div>';
  }

  function viewPeople() {
    return commitmentsHTML() +
      '<div class="search-wrap" style="margin-top:16px"><input class="input" id="peopleSearch" type="search" placeholder="搜索名字或备注" value="' + esc(peopleQuery) + '"></div>' +
      '<div class="panel" id="peopleList">' + peopleListHTML() + '</div>' +
      '<div style="margin-top:12px"><button class="btn wide" type="button" data-act="add-person">＋ 新建一个人</button></div>' +
      '<div class="faint" style="margin-top:14px;line-height:1.7">上面是还没了的账，下面是按「最久没联系」排的人。关系变淡，通常不是因为忘了这个人，是因为忘了那件答应过的事。</div>';
  }

  /* ================= 视图：某个人 ================= */
  function viewPerson(id) {
    var p = getPerson(id);
    if (!p) return emptyHTML('找不到这个人', '可能已经被删除了。');

    var evs = db.events.filter(function (e) { return (e.people || []).indexOf(id) >= 0; })
      .sort(function (a, b) { return b.ts - a.ts; });

    var mine = db.todos.filter(function (t) { return t.personId === id && t.dir !== 'them'; });
    var theirs = db.todos.filter(function (t) { return t.personId === id && t.dir === 'them'; });

    function commitHTML(t) {
      return '<div class="todo" data-done="' + (t.done ? '1' : '0') + '">' +
        '<button class="todo__check" type="button" data-act="toggle-todo" data-id="' + t.id + '" aria-label="完成">✓</button>' +
        '<div class="todo__text">' + esc(t.text) + '</div></div>';
    }

    var html = '<div class="row" style="gap:12px;margin-bottom:14px">' +
      '<div class="avatar" style="width:48px;height:48px;font-size:19px">' + esc((p.name || '?').slice(0, 1)) + '</div>' +
      '<div style="flex:1;min-width:0">' +
      '<div style="font-size:19px;font-weight:650">' + esc(p.name) + '</div>' +
      '<div class="muted">' + esc(p.lastTouch ? relDays(p.lastTouch) : '还没有互动记录') + ' · ' + evs.length + ' 条记录</div>' +
      '</div></div>';

    html += '<div class="panel">' +
      '<div class="field"><label>关于 TA（怎么认识的、在意什么、近况）</label>' +
      '<textarea class="textarea" id="personFacts" data-pid="' + p.id + '" placeholder="例：大学室友，做产品的。女儿刚上小学。不喜欢被临时约。">' + esc(p.facts || '') + '</textarea></div>' +
      '<div class="field" style="margin-bottom:0"><label>下次可以聊</label>' +
      '<input class="input" id="personHook" data-pid="' + p.id + '" value="' + esc(p.hook || '') + '" placeholder="例：问问他换工作的事">' +
      '</div></div>';

    html += '<div class="section-title">我答应 TA 的 <span class="count">' + mine.filter(function (t) { return !t.done; }).length + '</span></div>' +
      '<div class="panel">' + (mine.length ? mine.map(commitHTML).join('') : '<div class="faint" style="padding:4px 0">没有</div>') +
      '<button class="btn btn--sm" type="button" data-act="add-commit" data-pid="' + p.id + '" data-dir="me" style="margin-top:8px">＋ 加一件</button></div>';

    html += '<div class="section-title">TA 答应我的 <span class="count">' + theirs.filter(function (t) { return !t.done; }).length + '</span></div>' +
      '<div class="panel">' + (theirs.length ? theirs.map(commitHTML).join('') : '<div class="faint" style="padding:4px 0">没有</div>') +
      '<button class="btn btn--sm" type="button" data-act="add-commit" data-pid="' + p.id + '" data-dir="them" style="margin-top:8px">＋ 加一件</button></div>';

    html += '<div class="section-title">关于 TA 的记录 <span class="count">' + evs.length + '</span></div>';
    if (evs.length) {
      html += '<div class="panel">' + evs.map(function (e) {
        return '<div class="entry" data-type="' + (e.type || 'flow') + '">' +
          '<div class="entry__time entry__time--wide">' + md(e.ts) + '</div>' +
          '<div class="entry__body"><div class="entry__text" data-act="entry" data-id="' + e.id + '">' + esc(e.text) + '</div>' +
          ((e.tags || []).length ? '<div class="entry__meta">' + e.tags.map(tagHTML).join('') + '</div>' : '') +
          '</div></div>';
      }).join('') + '</div>';
    } else {
      html += emptyHTML('还没有互动记录', '在「快记」里写一条带 @' + p.name + ' 的流水就会出现在这里。');
    }

    html += '<div style="margin-top:16px;display:flex;gap:8px">' +
      '<button class="btn" type="button" data-act="log-for-person" data-id="' + p.id + '">记一笔关于 TA 的</button>' +
      '<button class="btn btn--danger" type="button" data-act="del-person" data-id="' + p.id + '">删除</button>' +
      '</div>';

    return html;
  }

  /* ================= 视图：经验卡 ================= */
  function cardsFiltered() {
    var q = cardsQuery.trim().toLowerCase();
    var arr = db.cards.slice();
    if (q) {
      arr = arr.filter(function (c) {
        return [c.scene, c.did, c.result, c.next, (c.tags || []).join(' ')].join(' ').toLowerCase().indexOf(q) >= 0;
      });
    }
    if (cardSort === 'recent') {
      arr.sort(function (a, b) { return (b.created || 0) - (a.created || 0); });
    } else if (cardSort === 'stale') {
      arr.sort(function (a, b) { return (a.lastUsed || 0) - (b.lastUsed || 0); });
    } else {
      arr.sort(function (a, b) { return (b.uses || 0) - (a.uses || 0); });
    }
    return arr;
  }

  function demoCardHTML() {
    return '<article class="card-item" style="opacity:.6;border-style:dashed">' +
      '<h3 class="card-item__scene">例：同事临下班让我接个活</h3>' +
      '<div class="card-item__next"><b>下次：</b>先问「什么时候要」，再说我手上还有什么，让对方选。</div>' +
      '<details><summary>当时的做法与结果</summary><div class="card-item__detail">' +
      '<b>当时的做法</b>直接答应了，加班到 11 点，自己的事没做完。' +
      '<b style="margin-top:10px">结果</b>对方没觉得这是帮忙，下次还这样。' +
      '</div></details>' +
      '<div class="card-item__foot"><span class="faint">这是示例，删不掉，也不用删</span></div></article>';
  }

  function cardsListHTML() {
    if (cardsMode === 'ideas') {
      var ideas = db.events.filter(function (e) { return e.type === 'idea'; })
        .sort(function (a, b) { return b.ts - a.ts; });
      var q = cardsQuery.trim().toLowerCase();
      if (q) ideas = ideas.filter(function (e) { return (e.text || '').toLowerCase().indexOf(q) >= 0; });
      if (!ideas.length) return emptyHTML('想法池是空的', '在快记里切到「想法」，随手丢一句进来。攒一阵再回头看，很多会自动归堆。');
      return '<div class="panel">' + ideas.map(function (e) {
        return '<div class="entry" data-type="idea">' +
          '<div class="entry__time">' + md(e.ts) + '</div>' +
          '<div class="entry__body"><div class="entry__text">' + esc(e.text) + '</div>' +
          '<div class="entry__meta"><button class="mini-link" type="button" data-act="idea-to-card" data-id="' + e.id + '">提炼成经验卡 →</button>' +
          '<button class="mini-link" type="button" data-act="del-event" data-id="' + e.id + '">删除</button></div>' +
          '</div></div>';
      }).join('') + '</div>';
    }

    var arr = cardsFiltered();
    if (!db.cards.length) {
      return '<div style="margin-bottom:6px">' + demoCardHTML() + '</div>' +
        emptyHTML('还没有自己的卡', '经验卡不是日记，是一条「下次遇到就这么做」的规则。') +
        '<div style="margin-top:4px"><button class="btn btn--primary wide" type="button" data-act="add-card">＋ 建第一张卡</button></div>';
    }
    if (!arr.length) return emptyHTML('没找到', '换个词试试。');
    return arr.map(cardHTML).join('');
  }

  function viewCards() {
    return '<div class="seg" style="margin-bottom:12px">' +
      '<button type="button" data-act="cards-mode" data-mode="cards" aria-pressed="' + (cardsMode === 'cards') + '">经验卡 ' + db.cards.length + '</button>' +
      '<button type="button" data-act="cards-mode" data-mode="ideas" aria-pressed="' + (cardsMode === 'ideas') + '">想法池 ' + db.events.filter(function (e) { return e.type === 'idea'; }).length + '</button>' +
      '</div>' +
      '<div class="search-wrap"><input class="input" id="cardsSearch" type="search" placeholder="搜场景、做法、标签" value="' + esc(cardsQuery) + '"></div>' +
      (cardsMode === 'cards'
        ? '<div class="row spread" style="margin-bottom:10px">' +
          '<select class="input" id="cardSort" style="width:auto;padding:6px 10px;font-size:13px;border-radius:999px">' +
          '<option value="recent"' + (cardSort === 'recent' ? ' selected' : '') + '>最近创建</option>' +
          '<option value="stale"' + (cardSort === 'stale' ? ' selected' : '') + '>最久没复习</option>' +
          '<option value="most"' + (cardSort === 'most' ? ' selected' : '') + '>最常用</option>' +
          '</select>' +
          '<button class="btn btn--sm" type="button" data-act="add-card">＋ 新建</button></div>'
        : '') +
      '<div id="cardsList">' + cardsListHTML() + '</div>';
  }

  /* ================= 视图：复盘 ================= */
  function weekStartTs() { return weekStartOf(Date.now()) - weekOffset * 7 * 86400000; }

  function getReview(week) {
    for (var i = 0; i < db.reviews.length; i++) if (db.reviews[i].week === week) return db.reviews[i];
    return null;
  }
  var saveWeekNote = debounce(function (week, text) {
    var r = getReview(week);
    if (!r) { r = { id: uid(), week: week, text: '', created: Date.now() }; db.reviews.push(r); }
    r.text = text;
    saveDB();
  }, 500);
  var saveSoon = debounce(saveDB, 400);

  /* ---------- 周报（规则生成，不调模型） ---------- */
  function getReport(week) {
    for (var i = 0; i < db.reports.length; i++) if (db.reports[i].week === week) return db.reports[i];
    return null;
  }

  function buildReport(ws, we) {
    var evs = db.events.filter(function (e) { return e.ts >= ws && e.ts < we; });
    var cards = db.cards.filter(function (c) { return c.created >= ws && c.created < we; });
    var open = db.todos.filter(function (t) { return !t.done && t.personId && t.created < we; });

    var tagCount = {};
    evs.forEach(function (e) {
      (e.tags || []).forEach(function (t) { tagCount[t] = (tagCount[t] || 0) + 1; });
    });
    var tags = Object.keys(tagCount).map(function (t) { return { tag: t, n: tagCount[t] }; })
      .sort(function (a, b) { return b.n - a.n; }).slice(0, 5);

    var words = topWords(evs.map(function (e) { return e.text; }).join(' '), 6);

    var drafts = [];
    tags.forEach(function (t) {
      if (t.n < 2) return;
      var list = evs.filter(function (e) { return (e.tags || []).indexOf(t.tag) >= 0; });
      drafts.push({
        tag: t.tag,
        lines: list.slice(0, 3).map(function (e) { return stripRefs(e.text); })
      });
    });

    return {
      week: 'w' + dayKey(ws),
      created: Date.now(),
      counts: { notes: evs.length, cards: cards.length, open: open.length },
      tags: tags,
      words: words,
      commits: open.slice(0, 6).map(function (t) {
        return { who: personName(t.personId), dir: t.dir, text: t.text, due: t.due || '' };
      }),
      drafts: drafts.slice(0, 3)
    };
  }

  function reportHTML(wk) {
    var r = getReport(wk);
    var head = '<div class="section-title">这周的报告 <span class="count">规则生成</span></div>';

    if (!r) {
      return head + '<div class="panel">' +
        '<div class="faint" style="line-height:1.8">把这一周过一遍：数一遍高频、挑出没兑现的承诺、给值得记的事起个头。不调模型，本地算。</div>' +
        '<button class="btn btn--primary wide" type="button" data-act="gen-report" style="margin-top:10px">生成这周的报告</button></div>';
    }

    var html = head + '<div class="panel">';
    html += '<div class="rep-lead">这周 <b>' + r.counts.notes + '</b> 条记录、<b>' + r.counts.cards +
      '</b> 张新卡、<b>' + r.counts.open + '</b> 笔承诺还没兑现。</div>';

    if (r.tags.length) {
      html += '<div class="rep-sec"><div class="rep-t">反复出现的标签</div><div class="rep-tags">' +
        r.tags.map(function (t) { return '<span class="tag">#' + esc(t.tag) + ' ×' + t.n + '</span>'; }).join('') +
        '</div></div>';
    }
    if (r.words.length) {
      html += '<div class="rep-sec"><div class="rep-t">高频词</div><div class="rep-tags">' +
        r.words.map(function (w) { return '<span class="tag">' + esc(w.w) + ' ×' + w.n + '</span>'; }).join('') +
        '</div></div>';
    }
    if (r.commits.length) {
      html += '<div class="rep-sec"><div class="rep-t">还没兑现的</div>';
      r.commits.forEach(function (c) {
        html += '<div class="rep-line">' +
          (c.dir === 'them' ? esc(c.who) + ' 欠我：' : '我欠 ' + esc(c.who) + '：') +
          esc(c.text) + (c.due ? '　<span class="faint">' + esc(c.due) + '</span>' : '') + '</div>';
      });
      html += '</div>';
    }
    if (r.drafts.length) {
      html += '<div class="rep-sec"><div class="rep-t">值得写成卡的</div>';
      r.drafts.forEach(function (d, i) {
        html += '<div class="rep-draft"><div class="rep-draft__h">#' + esc(d.tag) + ' · ' + d.lines.length + ' 次</div>' +
          d.lines.map(function (l) { return '<div class="rep-draft__l">' + esc(l) + '</div>'; }).join('') +
          '<button class="btn btn--sm" type="button" data-act="draft-card" data-i="' + i + '" style="margin-top:8px">就这条，补一句「下次」</button></div>';
      });
      html += '</div>';
    } else {
      html += '<div class="rep-sec"><div class="faint">这周没有重复出现两次以上的标签，还不用硬凑一张卡。</div></div>';
    }

    html += '<div class="row" style="margin-top:10px"><button class="btn btn--sm" type="button" data-act="gen-report">重新生成</button></div>';
    return html + '</div>';
  }

  function viewReview() {
    var ws = weekStartTs();
    var we = ws + 7 * 86400000;
    var wk = 'w' + dayKey(ws);

    var evs = db.events.filter(function (e) { return e.ts >= ws && e.ts < we; })
      .sort(function (a, b) { return a.ts - b.ts; });
    var cardsAdded = db.cards.filter(function (c) { return c.created >= ws && c.created < we; }).length;
    var uses = 0;
    db.cards.forEach(function (c) { if (c.lastUsed >= ws && c.lastUsed < we) uses += 1; });

    var html = '<div class="week-nav">' +
      '<button class="btn btn--sm" type="button" data-act="week-prev">‹ 上一周</button>' +
      '<div class="week-nav__label">' + md(ws) + ' – ' + md(we - 86400000) +
      (weekOffset === 0 ? ' <span class="faint">本周</span>' : '') + '</div>' +
      (weekOffset > 0
        ? '<button class="btn btn--sm" type="button" data-act="week-next">下一周 ›</button>'
        : '<button class="btn btn--sm" type="button" data-act="week-next" disabled style="opacity:.35">下一周 ›</button>') +
      '</div>';

    html += '<div class="panel"><div class="stat-grid">' +
      '<div><b>' + evs.length + '</b><small>条记录</small></div>' +
      '<div><b>' + cardsAdded + '</b><small>张新卡</small></div>' +
      '<div><b>' + uses + '</b><small>次用上</small></div>' +
      '</div></div>';

    /* 本周流水，按天分组 */
    html += '<div class="section-title">这一周 <span class="count">勾到卡就算沉淀了</span></div>';
    if (!evs.length) {
      html += emptyHTML('这一周没有记录', weekOffset === 0 ? '现在还来得及，去快记写一句。' : '过去就过去了。');
    } else {
      var byDay = {};
      evs.forEach(function (e) { (byDay[dayKey(e.ts)] = byDay[dayKey(e.ts)] || []).push(e); });
      var order = Object.keys(byDay).sort();
      html += '<div class="panel">';
      order.forEach(function (k) {
        var d = new Date(k + 'T00:00:00');
        html += '<div class="review-day"><div class="review-day__head">' + dayLabel(d.getTime()) + ' · ' + byDay[k].length + ' 条</div>';
        byDay[k].forEach(function (e) {
          html += '<div class="review-day__item"><span>' +
            (e.type === 'idea' ? '<span class="tag tag--idea">想法</span> ' : '') +
            esc(e.text) + '</span>' +
            '<button class="mini-link" type="button" data-act="event-to-card" data-id="' + e.id + '">→ 卡</button></div>';
        });
        html += '</div>';
      });
      html += '</div>';
    }

    /* 周报 */
    html += reportHTML(wk);

    /* 周记 */
    var r = getReview(wk);
    html += '<div class="section-title">这周的一句话</div>' +
      '<div class="panel"><textarea class="textarea" id="weekNote" data-week="' + wk + '" placeholder="这周反复出现的是什么？我哪里做对了、哪里又犯了老毛病？">' +
      esc(r ? r.text : '') + '</textarea>' +
      '<div class="faint" style="margin-top:6px">自动保存。写不出来就先空着，别硬编。</div></div>';

    /* 备份 */
    var days = backupAgeDays();
    html += '<div class="section-title">数据</div>' +
      '<div class="panel">' +
      '<div class="row spread" style="margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid var(--line)">' +
      '<div id="syncStatus" style="font-size:13.5px;color:var(--muted)">' + syncStatusHTML() + '</div>' +
      (hasCloud() && Cloud.signedIn() ? '<button class="btn btn--sm" type="button" data-act="sync-now">立即同步</button>' : '') +
      '</div>' +
      '<div class="row spread"><div>' +
      '<div style="font-size:14.5px">备份</div>' +
      '<div class="faint">' + (days === 999 ? '还从未导出过' : days === 0 ? '今天备份过' : days + ' 天前导出的') +
      ' · 共 ' + (db.events.length + db.cards.length + db.people.length + db.todos.length) + ' 条</div>' +
      '</div><button class="btn btn--sm" type="button" data-act="backup">导出 JSON</button></div>' +
      '<div class="row" style="margin-top:12px;gap:8px">' +
      '<button class="btn btn--sm" type="button" data-act="import">从文件恢复</button>' +
      '<span class="faint">连续记录 ' + streakDays() + ' 天</span>' +
      '</div></div>';

    return html;
  }

  function streakDays() {
    var days = {};
    db.events.forEach(function (e) { days[dayKey(e.ts)] = 1; });
    var n = 0, t = Date.now();
    if (!days[dayKey(t)]) t -= 86400000;
    while (days[dayKey(t)]) { n++; t -= 86400000; }
    return n;
  }

  /* ================= 视图：搜索 ================= */
  function groupHTML(title, rowsHTML, count, more) {
    if (!count) return '';
    return '<div class="section-title">' + title + ' <span class="count">' + count + '</span></div>' +
      '<div class="panel">' + rowsHTML + '</div>' +
      (more > 0 ? '<div class="faint" style="margin:-2px 2px 0">还有 ' + more + ' 条没显示，把关键词说细一点</div>' : '');
  }

  function searchResultsHTML() {
    var q = searchQuery.trim();
    if (!q) {
      return '<div class="empty"><b>搜什么？</b>人名、场景、关键词都行。<br>多个词用空格分开，会同时匹配。' +
        '<br><br>例：<code>临时 加班</code>　<code>拒绝</code>　<code>#工作</code></div>';
    }
    var ts = splitTerms(q);
    var out = '', total = 0;

    var ppl = db.people.filter(function (p) {
      return hit(p.name, ts) || hit(p.facts, ts) || hit(p.hook, ts);
    });
    total += ppl.length;
    if (ppl.length) {
      var rows = ppl.slice(0, 20).map(function (p) {
        var sub = hit(p.facts, ts) ? snip(p.facts, ts, 50) : (hit(p.hook, ts) ? snip(p.hook, ts, 50) : '');
        return '<div class="person-row" data-act="open-person" data-id="' + p.id + '">' +
          '<div class="avatar">' + esc((p.name || '?').slice(0, 1)) + '</div>' +
          '<div class="person-row__main">' +
          '<div class="person-row__name">' + hl(p.name, ts) + '</div>' +
          (sub ? '<div class="person-row__meta">' + hl(sub, ts) + '</div>' : '') +
          '</div></div>';
      }).join('');
      out += groupHTML('人', rows, ppl.length, ppl.length - 20);
    }

    var cards = db.cards.filter(function (c) {
      return hit(c.scene, ts) || hit(c.did, ts) || hit(c.result, ts) || hit(c.next, ts) || hitList(c.tags, ts);
    });
    total += cards.length;
    if (cards.length) {
      var crows = cards.slice(0, 20).map(function (c) {
        return '<div class="srow" data-act="edit-card" data-id="' + c.id + '">' +
          '<div class="srow__title">' + hl(c.scene, ts) + '</div>' +
          '<div class="srow__sub">下次：' + hl(snip(c.next, ts, 70), ts) + '</div></div>';
      }).join('');
      out += groupHTML('经验卡', crows, cards.length, cards.length - 20);
    }

    var evs = db.events.filter(function (e) {
      return hit(e.text, ts) || hitList(e.tags, ts) || hitList((e.people || []).map(personName), ts);
    }).sort(function (a, b) { return b.ts - a.ts; });
    total += evs.length;
    if (evs.length) {
      var erows = evs.slice(0, 30).map(function (e) {
        var meta = md(e.ts) + ' ' + hm(e.ts) + (e.type === 'idea' ? ' · 想法' : '');
        var who = (e.people || []).map(personName).filter(Boolean).join(' ');
        if (who) meta += ' · @' + who;
        return '<div class="srow" data-act="entry" data-id="' + e.id + '">' +
          '<div class="srow__meta">' + esc(meta) + '</div>' +
          '<div class="srow__title">' + hl(snip(e.text, ts, 110), ts) + '</div></div>';
      }).join('');
      out += groupHTML('记录', erows, evs.length, evs.length - 30);
    }

    var tds = db.todos.filter(function (t) { return hit(t.text, ts); });
    total += tds.length;
    if (tds.length) {
      var trows = tds.slice(0, 15).map(function (t) {
        var who = t.personId ? personName(t.personId) : '';
        return '<div class="todo" data-done="' + (t.done ? '1' : '0') + '">' +
          '<button class="todo__check" type="button" data-act="toggle-todo" data-id="' + t.id + '">✓</button>' +
          '<div class="todo__text">' + hl(t.text, ts) +
          (who ? '<span class="who">' + esc(who) + '</span>' : '') + '</div></div>';
      }).join('');
      out += groupHTML('待办', trows, tds.length, tds.length - 15);
    }

    var rvs = db.reviews.filter(function (r) { return hit(r.text, ts); });
    total += rvs.length;
    if (rvs.length) {
      var rrows = rvs.slice(0, 10).map(function (r) {
        var dk = String(r.week || '').replace(/^w/, '');
        var d = new Date(dk + 'T00:00:00');
        var label = isNaN(d.getTime()) ? '周记' : md(d.getTime()) + ' 那周';
        return '<div class="srow" data-act="open-week" data-week="' + esc(r.week) + '">' +
          '<div class="srow__meta">' + esc(label) + '</div>' +
          '<div class="srow__title">' + hl(snip(r.text, ts, 110), ts) + '</div></div>';
      }).join('');
      out += groupHTML('周记', rrows, rvs.length, rvs.length - 10);
    }

    if (!total) {
      return '<div class="empty"><b>没有找到</b>换个词试试。也可以直接搜人名的字，或者 #标签。</div>';
    }
    return '<div class="faint" style="margin:0 2px 2px">共 ' + total + ' 条</div>' + out;
  }

  function viewSearch() {
    return '<div class="search-wrap"><input class="input" id="globalSearch" type="search" placeholder="搜记录、卡片、人、待办、周记" value="' + esc(searchQuery) + '" autocomplete="off" autocorrect="off"></div>' +
      '<div id="searchResults">' + searchResultsHTML() + '</div>';
  }

  /* ================= 渲染 ================= */
  function render() {
    var r = parseRoute();
    var key = r.name + '/' + r.arg;
    var sameRoute = key === lastRouteKey;
    lastRouteKey = key;

    setTab(r.name);

    var title = '今天';
    var back = $('#backBtn');

    if (r.name === 'person') {
      var p = getPerson(r.arg);
      title = p ? p.name : '人';
    } else if (r.name === 'search') {
      title = '搜索';
    } else {
      title = r.name === 'people' ? '人' : r.name === 'cards' ? '经验卡' : r.name === 'review' ? '复盘' : '今天';
    }
    back.classList.toggle('hide', !(r.name === 'person' || r.name === 'search'));
    $('#topTitle').textContent = title;

    var body = '';
    if (r.name === 'person') body = viewPerson(r.arg);
    else if (r.name === 'people') body = viewPeople();
    else if (r.name === 'cards') body = viewCards();
    else if (r.name === 'review') body = viewReview();
    else if (r.name === 'search') body = viewSearch();
    else body = viewToday();

    $('#view').innerHTML = body;

    if (!sameRoute) window.scrollTo(0, 0);
    if (r.name === 'today') {
      var ta = $('#composerText');
      if (ta) { autoGrow(ta); updateSend(); }
    }
    if (r.name === 'search' && !sameRoute) {
      var si = $('#globalSearch');
      if (si) si.focus();
    }
  }

  function autoGrow(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 180) + 'px';
  }
  function updateSend() {
    var ta = $('#composerText'), b = $('#sendBtn');
    if (ta && b) b.disabled = !ta.value.trim();
  }

  /* ================= 操作 ================= */
  function commitComposer() {
    var ta = $('#composerText');
    if (!ta) return;
    var text = ta.value.trim();
    if (!text) return;

    var nextEl = $('#nextText');
    var nextVal = nextEl ? nextEl.value.trim() : '';
    var entry = null;
    var newCard = null;
    var newTodo = null;

    if (composerType === 'todo') {
      db.todos.unshift({ id: uid(), created: Date.now(), text: text, done: false, personId: '', dir: '' });
    } else {
      var refs = parseEntry(text);
      entry = {
        id: uid(), ts: Date.now(), type: composerType, text: text,
        tags: refs.tags, people: refs.people
      };
      db.events.unshift(entry);
      touchPeople(refs.people, Date.now());
      if (refs.created.length) toast('已新建人物：' + refs.created.join('、'));

      // 写了「下次怎么做」，就地变成一张卡，不再需要事后手动提炼
      if (nextVal) {
        newCard = {
          id: uid(), scene: clamp(stripRefs(text), 48), did: '', result: '',
          next: nextVal, tags: refs.tags, created: Date.now(), uses: 0, lastUsed: 0
        };
        db.cards.unshift(newCard);
      }

      // 认出了承诺，就顺手记一笔，挂在人身上
      if (refs.commitment) {
        newTodo = {
          id: uid(), created: Date.now(), text: refs.commitment.text,
          done: false, personId: refs.commitment.personId,
          dir: refs.commitment.dir, due: refs.commitment.due
        };
        db.todos.unshift(newTodo);
      }
    }

    draft = '';
    nextDraft = '';
    nextOpen = false;
    saveDB();
    render();

    var t2 = $('#composerText');
    if (t2 && composerType !== 'todo') { t2.focus(); t2.setSelectionRange(0, 0); }
    updateSend();

    if (entry) afterSave(entry, newCard ? newCard.id : '', newTodo);
  }

  /* 写完那一条之后，把它可能踩到的旧坑摆到眼前 */
  function afterSave(entry, newCardId, newTodo) {
    var tags = entry.tags || [];
    var hit = null;

    if (tags.length) {
      for (var i = 0; i < db.cards.length && !hit; i++) {
        var c = db.cards[i];
        if (c.id === newCardId) continue;
        var ct = c.tags || [];
        for (var j = 0; j < ct.length; j++) {
          if (tags.indexOf(ct[j]) >= 0) { hit = c; break; }
        }
      }
    }

    var owes = [];
    (entry.people || []).forEach(function (pid) {
      db.todos.forEach(function (td) {
        if (td.done || td.personId !== pid) return;
        if (newTodo && td.id === newTodo.id) return;
        owes.push({ pid: pid, text: td.text, due: td.due || '' });
      });
    });

    if (!hit && !owes.length && !newTodo) return;

    var body = '';

    if (newTodo) {
      body += '<div class="hit"><div class="hit__label">已记下这笔承诺</div>' +
        '<div class="hit__next">' +
        (newTodo.dir === 'them' ? esc(personName(newTodo.personId)) + ' 答应我：' : '我答应 ' + esc(personName(newTodo.personId)) + '：') +
        nl2br(newTodo.text) + (newTodo.due ? '　<span class="faint">' + esc(newTodo.due) + '</span>' : '') +
        '</div>' +
        '<div class="faint" style="margin-top:6px">认错了就点下面「知道了」，再去「人」里删掉。</div></div>';
    }

    if (hit) {
      body += '<div class="hit"><div class="hit__label">上次你说过</div>' +
        '<div class="hit__next">' + nl2br(hit.next) + '</div>' +
        '<div style="margin-top:8px"><button class="btn btn--sm" type="button" id="hitUse">这次照做了</button></div></div>';
    }

    owes.slice(0, 2).forEach(function (o) {
      body += '<div class="hit"><div class="hit__label">你还欠 ' + esc(personName(o.pid)) + '</div>' +
        '<div class="hit__next">' + nl2br(o.text) + (o.due ? '　<span class="faint">' + esc(o.due) + '</span>' : '') + '</div></div>';
    });

    openSheet(
      '<div class="sheet__title">等一下</div>' +
      '<div class="muted" style="margin:-6px 0 12px">不是要你做什么，只是让你看一眼。</div>' +
      body +
      '<div class="sheet__actions"><button class="btn btn--primary" type="button" id="hitOk">知道了</button></div>',
      function (sh) {
        $('#hitOk', sh).onclick = closeSheet;
        var u = $('#hitUse', sh);
        if (u && hit) u.onclick = function () { closeSheet(); useCard(hit.id); };
      });
  }

  function toggleTodo(id) {
    for (var i = 0; i < db.todos.length; i++) {
      if (db.todos[i].id === id) {
        db.todos[i].done = !db.todos[i].done;
        db.todos[i].doneAt = db.todos[i].done ? Date.now() : 0;
        break;
      }
    }
    saveDB(); render();
  }

  function deleteEvent(id) {
    db.events = db.events.filter(function (e) { return e.id !== id; });
    saveDB(); render(); toast('已删除');
  }

  function useCard(id) {
    db.cards.forEach(function (c) {
      if (c.id === id) { c.uses = (c.uses || 0) + 1; c.lastUsed = Date.now(); }
    });
    saveDB(); render(); toast('记一次，这张卡更牢了');
  }

  /* ================= 弹层 ================= */
  var sheetToken = 0;

  function closeSheet() {
    var bd = $('#sheetBackdrop');
    document.body.style.overflow = '';
    if (!bd) return;
    bd.classList.remove('open');
    var my = ++sheetToken;
    setTimeout(function () { if (my === sheetToken) $('#sheetRoot').innerHTML = ''; }, 220);
  }

  function openSheet(html, onMount) {
    sheetToken++;
    var root = $('#sheetRoot');
    root.innerHTML = '<div class="sheet-backdrop" id="sheetBackdrop"><div class="sheet" role="dialog" aria-modal="true">' +
      '<div class="sheet__grab"></div>' + html + '</div></div>';
    var bd = $('#sheetBackdrop');
    void bd.offsetHeight;
    bd.classList.add('open');
    document.body.style.overflow = 'hidden';
    bd.addEventListener('mousedown', function (e) { if (e.target === bd) closeSheet(); });
    bd.addEventListener('touchstart', function (e) { if (e.target === bd) closeSheet(); }, { passive: true });
    if (onMount) onMount($('.sheet', bd));
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && $('#sheetBackdrop')) closeSheet();
  });

  /* --- 条目操作 --- */
  function entrySheet(id) {
    var e = null;
    db.events.forEach(function (x) { if (x.id === id) e = x; });
    if (!e) return;
    openSheet(
      '<div class="sheet__title">这一条</div>' +
      '<div class="muted" style="margin-bottom:14px;white-space:pre-wrap">' + esc(e.text) + '</div>' +
      '<div class="menu-list">' +
      '<button type="button" id="sToCard">提炼成经验卡 <small>变成下次能用的规则</small></button>' +
      '<button type="button" id="sEdit">编辑文字</button>' +
      '<button type="button" id="sDel" class="danger">删除</button>' +
      '</div>',
      function (sh) {
        $('#sToCard', sh).onclick = function () { closeSheet(); openCardSheet(null, { scene: clamp(e.text, 60), did: e.text }); };
        $('#sEdit', sh).onclick = function () {
          closeSheet();
          openSheet(
            '<div class="sheet__title">编辑</div>' +
            '<div class="field"><textarea class="textarea" id="edText" style="min-height:110px">' + esc(e.text) + '</textarea></div>' +
            '<div class="sheet__actions"><button class="btn" type="button" id="edCancel">取消</button>' +
            '<button class="btn btn--primary" type="button" id="edSave">保存</button></div>',
            function (s2) {
              $('#edCancel', s2).onclick = closeSheet;
              $('#edSave', s2).onclick = function () {
                var v = $('#edText', s2).value.trim();
                if (!v) return;
                db.events.forEach(function (x) { if (x.id === e.id) { x.text = v; var r2 = parseEntry(v); x.tags = r2.tags; x.people = r2.people; } });
                saveDB(); closeSheet(); render(); toast('已保存');
              };
            });
        };
        $('#sDel', sh).onclick = function () {
          if (!confirm('删掉这条记录？')) return;
          deleteEvent(e.id); closeSheet();
        };
      });
  }

  /* --- 经验卡编辑 --- */
  function openCardSheet(card, preset) {
    var isNew = !card;
    var c = card || { scene: '', did: '', result: '', next: '', tags: [] };
    var pre = preset || {};
    var scene = pre.scene != null ? pre.scene : c.scene;
    var did = pre.did != null ? pre.did : c.did;

    openSheet(
      '<div class="sheet__title">' + (isNew ? '新建经验卡' : '编辑经验卡') + '</div>' +
      '<div class="field"><label>场景 · 什么情况下</label>' +
      '<textarea class="textarea" id="cScene" style="min-height:60px" placeholder="例：同事临下班让我接个活">' + esc(scene) + '</textarea></div>' +
      '<div class="field"><label>我当时怎么做的</label>' +
      '<textarea class="textarea" id="cDid" style="min-height:60px">' + esc(did) + '</textarea></div>' +
      '<div class="field"><label>结果</label>' +
      '<textarea class="textarea" id="cResult" style="min-height:60px">' + esc(c.result || '') + '</textarea></div>' +
      '<div class="field"><label>下次怎么做 · 一句话，可执行</label>' +
      '<textarea class="textarea" id="cNext" style="min-height:76px;border-color:var(--accent)" placeholder="例：先问截止时间，再说我手上有什么，让对方选">' + esc(c.next || '') + '</textarea></div>' +
      '<div class="field"><label>标签（逗号分隔，可空）</label>' +
      '<input class="input" id="cTags" value="' + esc((c.tags || []).join(',')) + '" placeholder="工作, 沟通"></div>' +
      '<div class="sheet__actions">' +
      (isNew ? '' : '<button class="btn btn--danger" type="button" id="cDel">删除</button>') +
      '<button class="btn" type="button" id="cCancel">取消</button>' +
      '<button class="btn btn--primary" type="button" id="cSave">保存</button></div>',
      function (sh) {
        $('#cScene', sh).focus();
        $('#cCancel', sh).onclick = closeSheet;
        if (!isNew) {
          $('#cDel', sh).onclick = function () {
            if (!confirm('删掉这张卡？')) return;
            db.cards = db.cards.filter(function (x) { return x.id !== c.id; });
            saveDB(); closeSheet(); render(); toast('已删除');
          };
        }
        $('#cSave', sh).onclick = function () {
          var scene2 = $('#cScene', sh).value.trim();
          var next2 = $('#cNext', sh).value.trim();
          if (!scene2) { toast('场景要写一句'); return; }
          if (!next2) { toast('「下次怎么做」是这张卡的核心'); return; }
          var tags = $('#cTags', sh).value.split(/[,，\s]+/).filter(Boolean);
          if (isNew) {
            db.cards.unshift({
              id: uid(), scene: scene2, did: $('#cDid', sh).value.trim(), result: $('#cResult', sh).value.trim(),
              next: next2, tags: tags, created: Date.now(), uses: 0, lastUsed: 0
            });
          } else {
            c.scene = scene2; c.did = $('#cDid', sh).value.trim(); c.result = $('#cResult', sh).value.trim();
            c.next = next2; c.tags = tags;
          }
          saveDB(); closeSheet(); render(); toast(isNew ? '卡片已建好' : '已保存');
        };
      });
  }

  /* --- 人物 --- */
  function openPersonSheet() {
    openSheet(
      '<div class="sheet__title">新建一个人</div>' +
      '<div class="field"><label>名字</label><input class="input" id="pName" placeholder="怎么称呼"></div>' +
      '<div class="field"><label>关于 TA（可后补）</label><textarea class="textarea" id="pFacts" placeholder="怎么认识的、在意什么、近况"></textarea></div>' +
      '<div class="sheet__actions"><button class="btn" type="button" id="pCancel">取消</button>' +
      '<button class="btn btn--primary" type="button" id="pSave">保存</button></div>',
      function (sh) {
        $('#pName', sh).focus();
        $('#pCancel', sh).onclick = closeSheet;
        $('#pSave', sh).onclick = function () {
          var n = $('#pName', sh).value.trim();
          if (!n) { toast('写个名字'); return; }
          if (findPersonByName(n)) { toast('已经有这个人了'); return; }
          var r = ensurePerson(n);
          r.person.facts = $('#pFacts', sh).value.trim();
          saveDB(); closeSheet(); go('#/person/' + r.person.id);
        };
      });
  }

  function openCommitSheet(pid, dir) {
    openSheet(
      '<div class="sheet__title">' + (dir === 'them' ? 'TA 答应我的事' : '我答应 TA 的事') + '</div>' +
      '<div class="field"><label>什么事</label><input class="input" id="cmText" placeholder="例：把他的简历转发给我"></div>' +
      '<div class="sheet__actions"><button class="btn" type="button" id="cmCancel">取消</button>' +
      '<button class="btn btn--primary" type="button" id="cmSave">加上</button></div>',
      function (sh) {
        $('#cmText', sh).focus();
        $('#cmCancel', sh).onclick = closeSheet;
        $('#cmSave', sh).onclick = function () {
          var v = $('#cmText', sh).value.trim();
          if (!v) return;
          db.todos.unshift({ id: uid(), created: Date.now(), text: v, done: false, personId: pid, dir: dir });
          saveDB(); closeSheet(); render(); toast('已记下');
        };
      });
  }

  function openLogForPerson(pid) {
    var p = getPerson(pid);
    if (!p) return;
    openSheet(
      '<div class="sheet__title">记一笔 · ' + esc(p.name) + '</div>' +
      '<div class="field"><textarea class="textarea" id="lgText" style="min-height:100px" placeholder="今天和他聊了什么、他提到什么事…"></textarea></div>' +
      '<div class="sheet__actions"><button class="btn" type="button" id="lgCancel">取消</button>' +
      '<button class="btn btn--primary" type="button" id="lgSave">保存</button></div>',
      function (sh) {
        $('#lgText', sh).focus();
        $('#lgCancel', sh).onclick = closeSheet;
        $('#lgSave', sh).onclick = function () {
          var v = $('#lgText', sh).value.trim();
          if (!v) return;
          db.events.unshift({ id: uid(), ts: Date.now(), type: 'flow', text: v, tags: [], people: [pid] });
          touchPeople([pid], Date.now());
          saveDB(); closeSheet(); render(); toast('已记录');
        };
      });
  }

  /* --- 菜单 --- */
  function openMenu() {
    var days = backupAgeDays();
    var signed = hasCloud() && Cloud.signedIn();
    var cloudBtns = '';

    if (!hasCloud()) {
      cloudBtns = '<div class="menu-note">本地模式 · 数据只在这台设备上</div>';
    } else if (!signed) {
      cloudBtns = '<button type="button" id="mCloud">登录云端 <small>已连上，但还没登录</small></button>';
    } else {
      cloudBtns =
        '<button type="button" id="mSync">立即同步 <small>' + esc(Cloud.email() || '') + '</small></button>' +
        '<button type="button" id="mHist">历史版本 <small>每天一份</small></button>' +
        '<button type="button" id="mOut">退出登录</button>';
    }

    openSheet(
      '<div class="sheet__title">底稿</div>' +
      '<div class="menu-list">' +
      cloudBtns +
      '<button type="button" id="mExport">导出备份 <small>' + (days === 999 ? '从未备份' : days === 0 ? '今天备份过' : days + ' 天前') + '</small></button>' +
      '<button type="button" id="mImport">从文件恢复</button>' +
      '<button type="button" id="mHelp">怎么用 <small>一分钟看完</small></button>' +
      '<button type="button" id="mClear" class="danger">清空所有数据</button>' +
      '</div>',
      function (sh) {
        if ($('#mCloud', sh)) {
          $('#mCloud', sh).onclick = function () {
            closeSheet();
            authMode = 'in';
            updateAuthGate();
          };
        }
        if ($('#mSync', sh)) $('#mSync', sh).onclick = function () { closeSheet(); doPush(); toast('开始同步…'); };
        if ($('#mHist', sh)) $('#mHist', sh).onclick = function () { closeSheet(); openHistory(); };
        if ($('#mOut', sh)) $('#mOut', sh).onclick = function () { closeSheet(); doSignOut(); };

        $('#mExport', sh).onclick = function () { closeSheet(); exportBackup(); };
        $('#mImport', sh).onclick = function () { closeSheet(); $('#importFile').click(); };
        $('#mClear', sh).onclick = function () {
          if (!confirm('清空所有数据？建议先导出备份。')) return;
          if (!confirm('再确认一次：这一步不可撤销。' + (signed ? '\n云端的记录也会一起清空。' : ''))) return;
          db = emptyDB(); saveDB(); closeSheet(); render(); toast('已清空');
        };
        $('#mHelp', sh).onclick = function () { closeSheet(); openHelp(); };
      });
  }

  function openHelp() {
    openSheet(
      '<div class="sheet__title">怎么用</div>' +
      '<div style="font-size:14.5px;line-height:1.75;color:var(--text)">' +
      '<p style="margin-top:0"><b>1. 随手记，别想格式。</b><br>一句话、一个时间点，写完就发。写到人就用 <code>@名字</code>，想归类就 <code>#标签</code>，都会自动生效。</p>' +
      '<p><b>2. 每周花 20 分钟复盘。</b><br>去「复盘」把这周过一遍，挑 1–3 条让你有感觉的事，点「→ 卡」，写成一条规则。</p>' +
      '<p><b>3. 经验卡只写「下次怎么做」。</b><br>场景 + 当时的做法 + 结果 + 一句可执行的话。别的都是陪衬。</p>' +
      '<p><b>4. 真遇到了，回来点「这次用上了」。</b><br>这会让这张卡排到「最久没复习」的后面，说明它已经进你脑子了。</p>' +
      '<p><b>5. 找东西用右上角放大镜。</b><br>一个词就够，记录、卡片、人、待办、周记会一起搜出来。多个词用空格分开，会同时匹配。</p>' +
      '<p><b>5. 每周导出一次备份。</b><br>数据只在这台设备的浏览器里，清缓存会没。</p>' +
      '</div>' +
      '<div class="sheet__actions"><button class="btn btn--primary" type="button" id="hOk">知道了</button></div>',
      function (sh) { $('#hOk', sh).onclick = closeSheet; });
  }

  /* --- 备份 --- */
  function exportBackup() {
    db.meta.lastBackup = Date.now();
    saveDB();
    var data = JSON.stringify(db, null, 2);
    var name = 'dibao-' + dayKey(Date.now()) + '.json';

    // 安卓 App 里 WebView 处理不了 blob 下载，交给原生写进「下载」目录
    if (window.AndroidBridge && typeof window.AndroidBridge.saveFile === 'function') {
      try {
        window.AndroidBridge.saveFile(name, data);
        render();
        return;
      } catch (e) { }
    }

    try {
      var blob = new Blob([data], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      toast('已导出 ' + name);
    } catch (e) {
      toast('导出失败，试试换个浏览器');
    }
    render();
  }

  function importBackup(file) {
    var reader = new FileReader();
    reader.onload = function () {
      var data;
      try { data = JSON.parse(String(reader.result)); }
      catch (e) { toast('文件读不出来，可能不是备份文件'); return; }
      if (!data || typeof data !== 'object') { toast('文件格式不对'); return; }
      if (!confirm('导入会覆盖当前所有数据，确定？')) return;
      try { localStorage.setItem(BAK, JSON.stringify(db)); } catch (e) { }
      db = normalize(data);
      saveDB();
      viewDate = startOfDay(Date.now());
      weekOffset = 0;
      render();
      toast('已恢复');
    };
    reader.readAsText(file);
  }

  /* ================= 事件绑定 ================= */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-act]');
    if (!t) return;
    var act = t.getAttribute('data-act');
    var id = t.getAttribute('data-id');

    switch (act) {
      case 'send': commitComposer(); break;
      case 'composer-type': composerType = t.getAttribute('data-type'); render(); {
        var ta = $('#composerText'); if (ta) ta.focus();
      } break;
      case 'toggle-next':
        nextOpen = true;
        render();
        var nEl = $('#nextText');
        if (nEl) nEl.focus();
        break;
      case 'day-prev': viewDate = startOfDay(viewDate - 86400000); render(); break;
      case 'day-next':
        if (dayKey(viewDate) !== dayKey(Date.now())) viewDate = startOfDay(viewDate + 86400000);
        render(); break;
      case 'day-today': viewDate = startOfDay(Date.now()); render(); break;
      case 'entry': entrySheet(id); break;
      case 'toggle-todo': toggleTodo(id); break;
      case 'toggle-done': showDone = !showDone; render(); break;
      case 'open-person': go('#/person/' + id); break;
      case 'add-person': openPersonSheet(); break;
      case 'add-commit': openCommitSheet(t.getAttribute('data-pid'), t.getAttribute('data-dir')); break;
      case 'log-for-person': openLogForPerson(id); break;
      case 'del-person':
        if (!confirm('删掉这个人？和他相关的记录会保留。')) break;
        db.people = db.people.filter(function (p) { return p.id !== id; });
        db.todos.forEach(function (x) { if (x.personId === id) { x.personId = ''; x.dir = ''; } });
        saveDB(); go('#/people'); toast('已删除');
        break;
      case 'add-card': openCardSheet(null); break;
      case 'edit-card': {
        var c = null;
        db.cards.forEach(function (x) { if (x.id === id) c = x; });
        if (c) openCardSheet(c);
        break;
      }
      case 'use-card': useCard(id); break;
      case 'event-to-card': {
        var ev = null;
        db.events.forEach(function (x) { if (x.id === id) ev = x; });
        if (ev) openCardSheet(null, { scene: clamp(ev.text, 60), did: ev.text });
        break;
      }
      case 'idea-to-card': {
        var iv = null;
        db.events.forEach(function (x) { if (x.id === id) iv = x; });
        if (iv) openCardSheet(null, { scene: clamp(iv.text, 60), did: '' });
        break;
      }
      case 'del-event':
        if (confirm('删掉这条？')) deleteEvent(id);
        break;
      case 'cards-mode': cardsMode = t.getAttribute('data-mode'); cardsQuery = ''; render(); break;
      case 'backup': exportBackup(); break;
      case 'sync-now': doPush(); toast('开始同步…'); break;
      case 'import': $('#importFile').click(); break;
      case 'week-prev': weekOffset++; render(); break;
      case 'week-next': if (weekOffset > 0) { weekOffset--; render(); } break;
      case 'gen-report': {
        var rws = weekStartTs();
        var rep = buildReport(rws, rws + 7 * 86400000);
        db.reports = db.reports.filter(function (x) { return x.week !== rep.week; });
        db.reports.push(rep);
        saveDB(); render(); toast('报告已生成');
        break;
      }
      case 'draft-card': {
        var rws2 = weekStartTs();
        var rep2 = getReport('w' + dayKey(rws2));
        var d = rep2 && rep2.drafts[Number(t.getAttribute('data-i'))];
        if (!d) break;
        openCardSheet(null, { scene: d.tag + '：' + (d.lines[0] || ''), did: d.lines.join('\n') });
        break;
      }
      case 'open-week': {
        var wk = String(t.getAttribute('data-week') || '').replace(/^w/, '');
        var wts = new Date(wk + 'T00:00:00').getTime();
        if (!isNaN(wts)) {
          weekOffset = Math.max(0, Math.round((weekStartOf(Date.now()) - wts) / (7 * 86400000)));
          go('#/review');
        }
        break;
      }
    }
  });

  document.addEventListener('input', function (e) {
    var el = e.target;
    if (el.id === 'composerText') {
      draft = el.value;
      autoGrow(el);
      updateSend();
    } else if (el.id === 'nextText') {
      nextDraft = el.value;
    } else if (el.id === 'peopleSearch') {
      peopleQuery = el.value;
      $('#peopleList').innerHTML = peopleListHTML();
    } else if (el.id === 'cardsSearch') {
      cardsQuery = el.value;
      $('#cardsList').innerHTML = cardsListHTML();
    } else if (el.id === 'globalSearch') {
      searchQuery = el.value;
      var box = $('#searchResults');
      if (box) box.innerHTML = searchResultsHTML();
    } else if (el.id === 'weekNote') {
      saveWeekNote(el.getAttribute('data-week'), el.value);
    } else if (el.id === 'personFacts' || el.id === 'personHook') {
      var p = getPerson(el.getAttribute('data-pid'));
      if (p) {
        if (el.id === 'personFacts') p.facts = el.value; else p.hook = el.value;
        saveSoon();
      }
    }
  });

  document.addEventListener('change', function (e) {
    if (e.target.id === 'cardSort') { cardSort = e.target.value; render(); }
    if (e.target.id === 'importFile') {
      var f = e.target.files && e.target.files[0];
      if (f) importBackup(f);
      e.target.value = '';
    }
  });

  document.addEventListener('keydown', function (e) {
    if (!e.target) return;
    if (e.target.id === 'composerText') {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        commitComposer();
      }
    } else if (e.target.id === 'nextText') {
      if (e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        commitComposer();
      }
    }
  });

  $('#tabbar').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-tab]');
    if (!b) return;
    var tab = b.getAttribute('data-tab');
    if (tab === 'today') viewDate = startOfDay(Date.now());
    if (tab === 'review') weekOffset = 0;
    go('#/' + tab);
  });

  $('#menuBtn').addEventListener('click', openMenu);
  $('#searchBtn').addEventListener('click', function () {
    if (parseRoute().name === 'search') { var si = $('#globalSearch'); if (si) si.focus(); }
    else go('#/search');
  });
  $('#backBtn').addEventListener('click', function () {
    if (history.length > 1) history.back();
    else go('#/people');
  });

  window.addEventListener('hashchange', function () { render(); });

  /* ================= 启动 ================= */
  loadDB();
  dailySnapshot();
  if (!location.hash) history.replaceState(null, '', '#/today');
  wireAuth();
  render();
  cloudBoot();

  window.addEventListener('online', function () {
    if (hasCloud() && Cloud.signedIn()) doPush();
  });

  // 回到前台时：有本地改动就补传，没有就看看云端有没有更新
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState !== 'visible') return;
    if (!hasCloud() || !Cloud.signedIn()) return;
    if (db.meta.dirty) { doPush(); return; }
    Cloud.pull().then(function (remote) {
      if (!remote) return;
      var localRev = Number(db.meta.rev) || 0;
      if (remote.rev > localRev && !db.meta.dirty) adoptRemote(remote);
    }).catch(function () { });
  });

  /* 注册 service worker（只在 http/https 下有效，file:// 打开时会跳过） */
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && location.hostname.indexOf('appassets') < 0) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () { });
    });
  }
})();
